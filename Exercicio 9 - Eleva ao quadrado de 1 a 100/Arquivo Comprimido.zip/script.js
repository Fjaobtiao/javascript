count = 0

while (count <= 100){
    if(count % 2 == 0)
    document.write(count*count, " ");
    count++;
}