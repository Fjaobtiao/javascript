count = 0

while (count < 100) {    
    document.write(count, " ")
    count += 3
}