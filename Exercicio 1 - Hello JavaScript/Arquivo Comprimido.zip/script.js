var varialvel = "Hello Word JavaScript";
var nome = "Jota Nascimento";
var idade = 47;
var nota = 9.8;

//Esse é um comentário

document.write(varialvel," meu nome é ",nome," tenho ",idade," anos, e essa aula foi nota ",nota,".");
alert("Acabei a Atividade");